# My First Project > 2025-07-08 3:58am
https://universe.roboflow.com/test-snzd0/my-first-project-vfduc

Provided by a Roboflow user
License: CC BY 4.0

